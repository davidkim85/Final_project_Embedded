#include "protocol.hpp"

#include <iomanip>
#include <sstream>
#include <stdexcept>

namespace protocol {

namespace {

bool isKnownPeripheral(std::uint8_t peripheral)
{
    return peripheral == PERIPHERAL_TIMER ||
           peripheral == PERIPHERAL_UART  ||
           peripheral == PERIPHERAL_SPI   ||
           peripheral == PERIPHERAL_I2C   ||
           peripheral == PERIPHERAL_ADC;
}

std::uint8_t parseHexByte(const std::string& token)
{
    if (token.empty() || token.size() > 2) {
        throw std::invalid_argument("Invalid hexadecimal byte: " + token);
    }

    unsigned value = 0;
    std::stringstream stream;
    stream << std::hex << token;

    if (!(stream >> value) || value > 0xFF) {
        throw std::invalid_argument("Invalid hexadecimal byte: " + token);
    }

    return static_cast<std::uint8_t>(value);
}

} // namespace

std::uint8_t peripheralFromName(const std::string& name)
{
    if (name == "timer") return PERIPHERAL_TIMER;
    if (name == "uart")  return PERIPHERAL_UART;
    if (name == "spi")   return PERIPHERAL_SPI;
    if (name == "i2c")   return PERIPHERAL_I2C;
    if (name == "adc")   return PERIPHERAL_ADC;

    throw std::invalid_argument(
        "Unknown peripheral. Use timer, uart, spi, i2c or adc.");
}

std::string peripheralName(std::uint8_t peripheral)
{
    switch (peripheral) {
        case PERIPHERAL_TIMER: return "TIMER";
        case PERIPHERAL_UART:  return "UART";
        case PERIPHERAL_SPI:   return "SPI";
        case PERIPHERAL_I2C:   return "I2C";
        case PERIPHERAL_ADC:   return "ADC";
        default: {
            std::ostringstream out;
            out << "UNKNOWN(0x"
                << std::uppercase << std::hex
                << std::setw(2) << std::setfill('0')
                << static_cast<unsigned>(peripheral)
                << ")";
            return out.str();
        }
    }
}

std::vector<std::uint8_t> parsePattern(const std::string& text)
{
    std::istringstream input(text);
    std::string token;
    std::vector<std::uint8_t> pattern;

    while (input >> token) {
        pattern.push_back(parseHexByte(token));

        if (pattern.size() > MAX_PATTERN_LENGTH) {
            throw std::invalid_argument(
                "Pattern cannot exceed 255 bytes.");
        }
    }

    if (pattern.empty()) {
        throw std::invalid_argument(
            "Pattern must contain at least one hexadecimal byte.");
    }

    return pattern;
}

std::vector<std::uint8_t> buildCommand(
    std::uint32_t testId,
    std::uint8_t peripheral,
    std::uint8_t iterations,
    const std::vector<std::uint8_t>& pattern)
{
    if (!isKnownPeripheral(peripheral)) {
        throw std::invalid_argument("Unknown peripheral value.");
    }

    if (iterations == 0) {
        throw std::invalid_argument("Iterations must be 1..255.");
    }

    if (pattern.size() > MAX_PATTERN_LENGTH) {
        throw std::invalid_argument(
            "Pattern cannot exceed 255 bytes.");
    }

    std::vector<std::uint8_t> packet;
    packet.reserve(7 + pattern.size());

    packet.push_back(static_cast<std::uint8_t>(testId & 0xFF));
    packet.push_back(static_cast<std::uint8_t>((testId >> 8) & 0xFF));
    packet.push_back(static_cast<std::uint8_t>((testId >> 16) & 0xFF));
    packet.push_back(static_cast<std::uint8_t>((testId >> 24) & 0xFF));

    packet.push_back(peripheral);
    packet.push_back(iterations);
    packet.push_back(static_cast<std::uint8_t>(pattern.size()));

    packet.insert(packet.end(), pattern.begin(), pattern.end());

    if (packet.size() > MAX_COMMAND_SIZE) {
        throw std::invalid_argument("Command is larger than protocol maximum.");
    }

    return packet;
}

void parseResult(
    const std::vector<std::uint8_t>& packet,
    std::uint32_t expectedTestId,
    std::uint32_t& returnedTestId,
    std::uint8_t& result)
{
    if (packet.size() != RESULT_SIZE) {
        throw std::runtime_error(
            "Invalid result length: " +
            std::to_string(packet.size()) +
            ", expected 5.");
    }

    returnedTestId =
        static_cast<std::uint32_t>(packet[0]) |
        (static_cast<std::uint32_t>(packet[1]) << 8) |
        (static_cast<std::uint32_t>(packet[2]) << 16) |
        (static_cast<std::uint32_t>(packet[3]) << 24);

    result = packet[4];

    if (returnedTestId != expectedTestId) {
        throw std::runtime_error(
            "Test-ID mismatch: expected " +
            std::to_string(expectedTestId) +
            ", received " +
            std::to_string(returnedTestId) + ".");
    }

    if (result != RESULT_SUCCESS && result != RESULT_FAILURE) {
        std::ostringstream out;
        out << "Unknown result code: 0x"
            << std::uppercase << std::hex
            << static_cast<unsigned>(result);
        throw std::runtime_error(out.str());
    }
}

} // namespace protocol
