#include "udp_client.hpp"
#include "protocol.hpp"

#include <arpa/inet.h>
#include <cerrno>
#include <cstring>
#include <netinet/in.h>
#include <stdexcept>
#include <sys/socket.h>
#include <unistd.h>

#include <chrono>

namespace {

std::vector<std::uint8_t> toVector(const std::uint8_t* data, std::size_t size)
{
    return std::vector<std::uint8_t>(data, data + size);
}

} // namespace

UdpClient::UdpClient(std::string ip, std::uint16_t port, double timeoutSeconds)
    : ip_(std::move(ip)),
      port_(port),
      timeoutSeconds_(timeoutSeconds)
{
}

UdpResult UdpClient::run(
    const std::vector<std::uint8_t>& command,
    std::uint32_t expectedTestId) const
{
    UdpResult result;

    const int socketFd = ::socket(AF_INET, SOCK_DGRAM, 0);
    if (socketFd < 0) {
        result.error = std::string("socket(): ") + std::strerror(errno);
        return result;
    }

    timeval timeout{};
    timeout.tv_sec = static_cast<long>(timeoutSeconds_);
    timeout.tv_usec = static_cast<suseconds_t>(
        (timeoutSeconds_ - timeout.tv_sec) * 1000000.0);

    if (::setsockopt(
            socketFd,
            SOL_SOCKET,
            SO_RCVTIMEO,
            &timeout,
            sizeof(timeout)) < 0) {
        result.error =
            std::string("setsockopt(SO_RCVTIMEO): ") +
            std::strerror(errno);
        ::close(socketFd);
        return result;
    }

    sockaddr_in destination{};
    destination.sin_family = AF_INET;
    destination.sin_port = htons(port_);

    if (::inet_pton(AF_INET, ip_.c_str(), &destination.sin_addr) != 1) {
        result.error = "Invalid STM32 IPv4 address: " + ip_;
        ::close(socketFd);
        return result;
    }

    const auto start = std::chrono::steady_clock::now();

    const ssize_t sent = ::sendto(
        socketFd,
        command.data(),
        command.size(),
        0,
        reinterpret_cast<const sockaddr*>(&destination),
        sizeof(destination));

    if (sent != static_cast<ssize_t>(command.size())) {
        const auto end = std::chrono::steady_clock::now();
        result.elapsedSeconds =
            std::chrono::duration<double>(end - start).count();
        result.error =
            std::string("sendto(): ") +
            (sent < 0 ? std::strerror(errno) : "partial UDP send");
        ::close(socketFd);
        return result;
    }

    std::uint8_t receiveBuffer[1024]{};
    sockaddr_in source{};
    socklen_t sourceLength = sizeof(source);

    const ssize_t received = ::recvfrom(
        socketFd,
        receiveBuffer,
        sizeof(receiveBuffer),
        0,
        reinterpret_cast<sockaddr*>(&source),
        &sourceLength);

    const auto end = std::chrono::steady_clock::now();
    result.elapsedSeconds =
        std::chrono::duration<double>(end - start).count();

    if (received < 0) {
        if (errno == EAGAIN || errno == EWOULDBLOCK) {
            result.error = "UDP receive timeout.";
        } else {
            result.error =
                std::string("recvfrom(): ") + std::strerror(errno);
        }
        ::close(socketFd);
        return result;
    }

    result.received = true;

    char sourceIp[INET_ADDRSTRLEN]{};
    if (::inet_ntop(
            AF_INET,
            &source.sin_addr,
            sourceIp,
            sizeof(sourceIp)) != nullptr) {
        result.remoteIp = sourceIp;
    }
    result.remotePort = ntohs(source.sin_port);

    try {
        const auto packet =
            toVector(receiveBuffer, static_cast<std::size_t>(received));

        protocol::parseResult(
            packet,
            expectedTestId,
            result.returnedTestId,
            result.resultCode);

        result.success =
            (result.resultCode == protocol::RESULT_SUCCESS);
    } catch (const std::exception& error) {
        result.success = false;
        result.error = error.what();
    }

    ::close(socketFd);
    return result;
}
