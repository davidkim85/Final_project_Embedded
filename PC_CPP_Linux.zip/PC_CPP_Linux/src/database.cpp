#include "database.hpp"
#include "protocol.hpp"

#include <sqlite3.h>

#include <stdexcept>

namespace {

void checkSqlite(int rc, sqlite3* db, const char* operation)
{
    if (rc != SQLITE_OK && rc != SQLITE_DONE && rc != SQLITE_ROW) {
        throw std::runtime_error(
            std::string(operation) + ": " + sqlite3_errmsg(db));
    }
}

TestRecord readRecord(sqlite3_stmt* stmt)
{
    TestRecord record;

    record.testId =
        static_cast<std::uint32_t>(sqlite3_column_int64(stmt, 0));

    record.dateTimeSent =
        reinterpret_cast<const char*>(
            sqlite3_column_text(stmt, 1));

    record.durationSeconds =
        sqlite3_column_double(stmt, 2);

    record.result =
        static_cast<std::uint8_t>(sqlite3_column_int(stmt, 3));

    record.resultText =
        reinterpret_cast<const char*>(
            sqlite3_column_text(stmt, 4));

    record.peripheral =
        reinterpret_cast<const char*>(
            sqlite3_column_text(stmt, 5));

    record.peripheralValue =
        static_cast<std::uint8_t>(sqlite3_column_int(stmt, 6));

    record.iterations =
        static_cast<std::uint8_t>(sqlite3_column_int(stmt, 7));

    record.patternHex =
        reinterpret_cast<const char*>(
            sqlite3_column_text(stmt, 8));

    return record;
}

} // namespace

Database::Database(const std::string& path)
{
    const int rc = sqlite3_open(path.c_str(), &db_);
    if (rc != SQLITE_OK) {
        const std::string message =
            db_ ? sqlite3_errmsg(db_) : "unknown SQLite error";
        if (db_) {
            sqlite3_close(db_);
            db_ = nullptr;
        }
        throw std::runtime_error("sqlite3_open(): " + message);
    }

    execute(
        "CREATE TABLE IF NOT EXISTS test_results ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT,"
        "test_id INTEGER NOT NULL,"
        "date_time_sent TEXT NOT NULL,"
        "test_length_seconds REAL NOT NULL,"
        "result INTEGER NOT NULL,"
        "result_text TEXT NOT NULL,"
        "peripheral INTEGER NOT NULL,"
        "peripheral_name TEXT NOT NULL,"
        "iterations INTEGER NOT NULL,"
        "pattern_hex TEXT NOT NULL"
        ");");
}

Database::~Database()
{
    if (db_) {
        sqlite3_close(db_);
        db_ = nullptr;
    }
}

void Database::execute(const std::string& sql) const
{
    char* errorMessage = nullptr;
    const int rc = sqlite3_exec(
        db_,
        sql.c_str(),
        nullptr,
        nullptr,
        &errorMessage);

    if (rc != SQLITE_OK) {
        const std::string message =
            errorMessage ? errorMessage : "unknown SQLite error";

        sqlite3_free(errorMessage);

        throw std::runtime_error(
            "SQLite execute: " + message);
    }
}

void Database::save(
    std::uint32_t testId,
    const std::string& dateTimeSent,
    double durationSeconds,
    std::uint8_t result,
    std::uint8_t peripheral,
    std::uint8_t iterations,
    const std::string& patternHex)
{
    constexpr const char* sql =
        "INSERT INTO test_results "
        "(test_id,date_time_sent,test_length_seconds,result,"
        "result_text,peripheral,peripheral_name,iterations,pattern_hex) "
        "VALUES (?,?,?,?,?,?,?,?,?);";

    sqlite3_stmt* stmt = nullptr;

    int rc = sqlite3_prepare_v2(
        db_, sql, -1, &stmt, nullptr);
    checkSqlite(rc, db_, "sqlite3_prepare_v2");

    const std::string peripheralText =
        protocol::peripheralName(peripheral);

    const std::string resultText =
        result == protocol::RESULT_SUCCESS
            ? "Success"
            : "Failure";

    sqlite3_bind_int64(
        stmt, 1, static_cast<sqlite3_int64>(testId));
    sqlite3_bind_text(
        stmt, 2, dateTimeSent.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_double(stmt, 3, durationSeconds);
    sqlite3_bind_int(stmt, 4, result);
    sqlite3_bind_text(
        stmt, 5, resultText.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt, 6, peripheral);
    sqlite3_bind_text(
        stmt, 7, peripheralText.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt, 8, iterations);
    sqlite3_bind_text(
        stmt, 9, patternHex.c_str(), -1, SQLITE_TRANSIENT);

    rc = sqlite3_step(stmt);
    checkSqlite(rc, db_, "sqlite3_step");

    sqlite3_finalize(stmt);
}

std::vector<TestRecord> Database::history() const
{
    constexpr const char* sql =
        "SELECT test_id,date_time_sent,test_length_seconds,"
        "result,result_text,peripheral_name,peripheral,"
        "iterations,pattern_hex "
        "FROM test_results ORDER BY id ASC;";

    sqlite3_stmt* stmt = nullptr;
    int rc = sqlite3_prepare_v2(
        db_, sql, -1, &stmt, nullptr);
    checkSqlite(rc, db_, "sqlite3_prepare_v2");

    std::vector<TestRecord> records;

    while ((rc = sqlite3_step(stmt)) == SQLITE_ROW) {
        records.push_back(readRecord(stmt));
    }

    if (rc != SQLITE_DONE) {
        sqlite3_finalize(stmt);
        checkSqlite(rc, db_, "sqlite3_step");
    }

    sqlite3_finalize(stmt);
    return records;
}

std::vector<TestRecord> Database::get(std::uint32_t testId) const
{
    constexpr const char* sql =
        "SELECT test_id,date_time_sent,test_length_seconds,"
        "result,result_text,peripheral_name,peripheral,"
        "iterations,pattern_hex "
        "FROM test_results WHERE test_id=? ORDER BY id ASC;";

    sqlite3_stmt* stmt = nullptr;
    int rc = sqlite3_prepare_v2(
        db_, sql, -1, &stmt, nullptr);
    checkSqlite(rc, db_, "sqlite3_prepare_v2");

    sqlite3_bind_int64(
        stmt, 1, static_cast<sqlite3_int64>(testId));

    std::vector<TestRecord> records;

    while ((rc = sqlite3_step(stmt)) == SQLITE_ROW) {
        records.push_back(readRecord(stmt));
    }

    if (rc != SQLITE_DONE) {
        sqlite3_finalize(stmt);
        checkSqlite(rc, db_, "sqlite3_step");
    }

    sqlite3_finalize(stmt);
    return records;
}
