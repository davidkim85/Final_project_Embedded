#include "database.hpp"
#include "protocol.hpp"
#include "udp_client.hpp"

#include <chrono>
#include <cstdint>
#include <ctime>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

namespace {

constexpr const char* STM32_IP = "192.168.1.198";
constexpr std::uint16_t STM32_PORT = 5000;
constexpr double DEFAULT_TIMEOUT = 5.0;

std::string nowLocalIso()
{
    const auto now = std::chrono::system_clock::now();
    const std::time_t timeValue =
        std::chrono::system_clock::to_time_t(now);

    std::tm localTime{};
    localtime_r(&timeValue, &localTime);

    std::ostringstream out;
    out << std::put_time(&localTime, "%Y-%m-%dT%H:%M:%S");

    return out.str();
}

std::string bytesToHex(const std::vector<std::uint8_t>& bytes)
{
    std::ostringstream out;

    for (std::size_t i = 0; i < bytes.size(); ++i) {
        if (i != 0) {
            out << ' ';
        }

        out << std::uppercase
            << std::hex
            << std::setw(2)
            << std::setfill('0')
            << static_cast<unsigned>(bytes[i]);
    }

    return out.str();
}

void printUsage()
{
    std::cout
        << "STM32 Manufacturing Test Client\n\n"
        << "Usage:\n"
        << "  manufacturing_test all\n"
        << "  manufacturing_test run --id ID --peripheral NAME "
           "--iterations N --pattern \"11 22 33\"\n"
        << "  manufacturing_test history\n"
        << "  manufacturing_test get --id ID\n\n"
        << "Peripheral names: timer, uart, spi, i2c, adc\n"
        << "STM32: " << STM32_IP << ":" << STM32_PORT << "\n";
}

std::string getOption(
    int argc,
    char* argv[],
    const std::string& name,
    bool required = true)
{
    for (int i = 0; i < argc; ++i) {
        if (argv[i] == name) {
            if (i + 1 >= argc) {
                throw std::invalid_argument(
                    "Missing value for " + name);
            }
            return argv[i + 1];
        }
    }

    if (required) {
        throw std::invalid_argument(
            "Missing required option " + name);
    }

    return {};
}

std::uint32_t parseUnsigned32(const std::string& text)
{
    std::size_t consumed = 0;
    const unsigned long long value =
        std::stoull(text, &consumed, 0);

    if (consumed != text.size() || value > 0xFFFFFFFFULL) {
        throw std::invalid_argument(
            "Invalid 32-bit unsigned value: " + text);
    }

    return static_cast<std::uint32_t>(value);
}

unsigned parseUnsigned8(const std::string& text)
{
    std::size_t consumed = 0;
    const unsigned long value =
        std::stoul(text, &consumed, 0);

    if (consumed != text.size() || value > 255U) {
        throw std::invalid_argument(
            "Invalid 8-bit unsigned value: " + text);
    }

    return static_cast<unsigned>(value);
}

void printTestHeader(
    std::uint32_t testId,
    std::uint8_t peripheral,
    std::uint8_t iterations,
    const std::vector<std::uint8_t>& pattern,
    const std::string& dateTimeSent,
    const std::vector<std::uint8_t>& command)
{
    std::cout << "\n" << std::string(60, '=') << "\n";
    std::cout << "TEST\n";
    std::cout << std::string(60, '=') << "\n";
    std::cout << "Test-ID     : " << testId << "\n";
    std::cout << "Peripheral  : "
              << protocol::peripheralName(peripheral)
              << " (0x"
              << std::uppercase << std::hex
              << std::setw(2) << std::setfill('0')
              << static_cast<unsigned>(peripheral)
              << std::dec << ")\n";
    std::cout << "Iterations  : "
              << static_cast<unsigned>(iterations) << "\n";
    std::cout << "Pattern     : "
              << bytesToHex(pattern) << "\n";
    std::cout << "Sent        : "
              << dateTimeSent << "\n";
    std::cout << "Command     : "
              << bytesToHex(command) << "\n";
}

bool runTest(
    Database& database,
    std::uint32_t testId,
    std::uint8_t peripheral,
    std::uint8_t iterations,
    const std::vector<std::uint8_t>& pattern,
    double timeout)
{
    const auto command = protocol::buildCommand(
        testId,
        peripheral,
        iterations,
        pattern);

    const std::string dateTimeSent = nowLocalIso();

    printTestHeader(
        testId,
        peripheral,
        iterations,
        pattern,
        dateTimeSent,
        command);

    UdpClient client(
        STM32_IP,
        STM32_PORT,
        timeout);

    const UdpResult result =
        client.run(command, testId);

    if (result.received) {
        std::cout << "Response    : "
                  << "Test-ID=" << result.returnedTestId
                  << " Result=0x"
                  << std::uppercase << std::hex
                  << std::setw(2) << std::setfill('0')
                  << static_cast<unsigned>(result.resultCode)
                  << std::dec << "\n";

        std::cout << "From        : "
                  << result.remoteIp << ":"
                  << result.remotePort << "\n";
    } else {
        std::cout << "Response    : TIMEOUT/ERROR\n";
    }

    std::cout << std::fixed
              << std::setprecision(6)
              << "Elapsed     : "
              << result.elapsedSeconds
              << " sec\n";

    if (!result.error.empty()) {
        std::cout << "Error       : "
                  << result.error << "\n";
    }

    std::cout << "Result      : "
              << (result.success ? "SUCCESS" : "FAILURE")
              << "\n";

    database.save(
        testId,
        dateTimeSent,
        result.elapsedSeconds,
        result.success
            ? protocol::RESULT_SUCCESS
            : protocol::RESULT_FAILURE,
        peripheral,
        iterations,
        bytesToHex(pattern));

    std::cout << "Database    : SAVED\n";

    return result.success;
}

void printHistory(const std::vector<TestRecord>& records)
{
    std::cout << "\n"
              << std::string(110, '=') << "\n"
              << "TEST HISTORY\n"
              << std::string(110, '=') << "\n";

    if (records.empty()) {
        std::cout << "No test results stored.\n";
        return;
    }

    std::cout
        << std::left
        << std::setw(9) << "TEST-ID" << ' '
        << std::setw(26) << "DATE/TIME" << ' '
        << std::setw(12) << "SECONDS" << ' '
        << std::setw(12) << "PERIPHERAL" << ' '
        << std::setw(7) << "ITER"
        << "RESULT\n";

    std::cout << std::string(110, '-') << "\n";

    for (const auto& record : records) {
        std::cout
            << std::left
            << std::setw(9) << record.testId << ' '
            << std::setw(26) << record.dateTimeSent << ' '
            << std::setw(12) << std::fixed
            << std::setprecision(6)
            << record.durationSeconds << ' '
            << std::setw(12) << record.peripheral << ' '
            << std::setw(7)
            << static_cast<unsigned>(record.iterations)
            << record.resultText
            << "\n";
    }
}

void printRecords(const std::vector<TestRecord>& records)
{
    if (records.empty()) {
        std::cout << "No records found.\n";
        return;
    }

    for (std::size_t i = 0; i < records.size(); ++i) {
        const auto& record = records[i];

        std::cout << "\nRecord      : " << (i + 1) << "\n";
        std::cout << "Test-ID     : " << record.testId << "\n";
        std::cout << "Date/Time   : " << record.dateTimeSent << "\n";
        std::cout << "Duration    : "
                  << std::fixed << std::setprecision(6)
                  << record.durationSeconds << " sec\n";
        std::cout << "Peripheral  : " << record.peripheral << "\n";
        std::cout << "Iterations  : "
                  << static_cast<unsigned>(record.iterations)
                  << "\n";
        std::cout << "Pattern     : " << record.patternHex << "\n";
        std::cout << "Result      : " << record.resultText
                  << " (0x"
                  << std::uppercase << std::hex
                  << std::setw(2) << std::setfill('0')
                  << static_cast<unsigned>(record.result)
                  << std::dec << ")\n";
        std::cout << std::string(70, '-') << "\n";
    }
}

bool runAll(Database& database)
{
    struct TestDefinition {
        std::uint32_t id;
        const char* peripheral;
        const char* pattern;
    };

    const TestDefinition tests[] = {
        {7001, "timer", "0A 00"},
        {7002, "uart",  "11 22 33 44 55"},
        {7003, "spi",   "11 22 33 44 55"},
        {7004, "i2c",   "11 22 33 44 55"},
        {7005, "adc",   "00 00"},
    };

    bool overallPass = true;

    std::cout << "\n"
              << std::string(70, '=') << "\n"
              << "FULL STM32 MANUFACTURING TEST\n"
              << std::string(70, '=') << "\n";

    for (const auto& test : tests) {
        const auto peripheral =
            protocol::peripheralFromName(test.peripheral);
        const auto pattern =
            protocol::parsePattern(test.pattern);

        const bool success = runTest(
            database,
            test.id,
            peripheral,
            3,
            pattern,
            DEFAULT_TIMEOUT);

        std::cout << "TEST-ID " << test.id
                  << " | "
                  << protocol::peripheralName(peripheral)
                  << " | "
                  << (success ? "PASS" : "FAIL")
                  << "\n";

        overallPass = overallPass && success;

        std::this_thread::sleep_for(
            std::chrono::milliseconds(100));
    }

    std::cout << "\n"
              << std::string(70, '=') << "\n"
              << (overallPass
                    ? "ALL MANUFACTURING TESTS: PASS"
                    : "MANUFACTURING TESTS: FAIL")
              << "\n"
              << std::string(70, '=') << "\n";

    return overallPass;
}

} // namespace

int main(int argc, char* argv[])
{
    try {
        if (argc < 2) {
            printUsage();
            return 2;
        }

        Database database("tests_cpp.db");

        const std::string command = argv[1];

        if (command == "history") {
            printHistory(database.history());
            return 0;
        }

        if (command == "get") {
            const auto idText =
                getOption(argc - 2, argv + 2, "--id");
            const auto testId = parseUnsigned32(idText);

            printRecords(database.get(testId));
            return 0;
        }

        if (command == "all") {
            return runAll(database) ? 0 : 1;
        }

        if (command == "run") {
            const auto id =
                parseUnsigned32(
                    getOption(argc - 2, argv + 2, "--id"));

            const auto peripheral =
                protocol::peripheralFromName(
                    getOption(
                        argc - 2,
                        argv + 2,
                        "--peripheral"));

            const auto iterationsValue =
                parseUnsigned8(
                    getOption(
                        argc - 2,
                        argv + 2,
                        "--iterations"));

            if (iterationsValue == 0) {
                throw std::invalid_argument(
                    "--iterations must be 1..255.");
            }

            const auto pattern =
                protocol::parsePattern(
                    getOption(
                        argc - 2,
                        argv + 2,
                        "--pattern"));

            return runTest(
                database,
                id,
                peripheral,
                static_cast<std::uint8_t>(iterationsValue),
                pattern,
                DEFAULT_TIMEOUT)
                ? 0
                : 1;
        }

        printUsage();
        return 2;

    } catch (const std::exception& error) {
        std::cerr << "ERROR: "
                  << error.what()
                  << "\n";
        return 2;
    }
}
