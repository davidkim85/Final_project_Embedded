# STM32 Manufacturing Test Client — C++ / Linux

This is the PC-side C++17 CLI client for the STM32 manufacturing-test project.

## Target

STM32 UUT:

- IP: `192.168.1.198`
- UDP port: `5000`

The client implements the assignment protocol:

### Command

```text
Test-ID        4 bytes, little-endian
Peripheral     1 byte
Iterations     1 byte
Pattern length 1 byte
Pattern        N bytes
```

### Result

```text
Test-ID        4 bytes, little-endian
Test Result    1 byte
```

Result values:

```text
0x01 = SUCCESS
0xFF = FAILURE
```

The client stores test records in SQLite and can print them on demand.

## Linux dependencies

Ubuntu/Debian:

```bash
sudo apt update
sudo apt install build-essential libsqlite3-dev
```

## Build

```bash
make
```

This creates:

```text
./manufacturing_test
```

## Run one test

UART:

```bash
./manufacturing_test run \
  --id 9001 \
  --peripheral uart \
  --iterations 3 \
  --pattern "11 22 33 44 55"
```

SPI:

```bash
./manufacturing_test run \
  --id 9002 \
  --peripheral spi \
  --iterations 3 \
  --pattern "11 22 33 44 55"
```

I2C:

```bash
./manufacturing_test run \
  --id 9003 \
  --peripheral i2c \
  --iterations 3 \
  --pattern "11 22 33 44 55"
```

Timer:

```bash
./manufacturing_test run \
  --id 9004 \
  --peripheral timer \
  --iterations 3 \
  --pattern "0A 00"
```

ADC:

```bash
./manufacturing_test run \
  --id 9005 \
  --peripheral adc \
  --iterations 3 \
  --pattern "00 00"
```

## Run all five tests

```bash
./manufacturing_test all
```

The integrated test sequence is:

```text
7001 TIMER
7002 UART
7003 SPI
7004 I2C
7005 ADC
```

## History

```bash
./manufacturing_test history
```

## Records for one Test-ID

```bash
./manufacturing_test get --id 9001
```

## Database

The C++ client creates:

```text
tests_cpp.db
```

The database contains:

```text
TEST-ID
Date/Time sent
Test length in seconds
Result
Peripheral
Iterations
Pattern
```

## Important board note

The assignment PDF specifies STM32F746ZG. The implemented and verified hardware is NUCLEO-F756ZG / STM32F756ZGTx. The peripheral configuration and pin mapping were adapted to the actual F756 target.

## Relation to the Python client

The existing Python client remains useful as a functional test/debug tool.

This C++ client is the formal PC-side implementation intended to satisfy the assignment requirement for a C/C++ CLI application on Linux.
