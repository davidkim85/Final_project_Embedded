#pragma once

#include <cstdint>
#include <string>
#include <vector>

struct UdpResult {
    bool received = false;
    bool success = false;
    std::uint32_t returnedTestId = 0;
    std::uint8_t resultCode = 0xFF;
    std::string remoteIp;
    std::uint16_t remotePort = 0;
    double elapsedSeconds = 0.0;
    std::string error;
};

/**
 * @brief UDP client for the STM32 manufacturing test server.
 */
class UdpClient {
public:
    UdpClient(std::string ip, std::uint16_t port, double timeoutSeconds);

    /**
     * @brief Sends one protocol command and waits for the 5-byte result.
     */
    UdpResult run(
        const std::vector<std::uint8_t>& command,
        std::uint32_t expectedTestId) const;

private:
    std::string ip_;
    std::uint16_t port_;
    double timeoutSeconds_;
};
