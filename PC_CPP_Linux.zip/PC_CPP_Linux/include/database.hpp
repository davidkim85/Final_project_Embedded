#pragma once

#include <cstdint>
#include <string>
#include <vector>

struct TestRecord {
    std::uint32_t testId = 0;
    std::string dateTimeSent;
    double durationSeconds = 0.0;
    std::uint8_t result = 0xFF;
    std::string resultText;
    std::string peripheral;
    std::uint8_t peripheralValue = 0;
    std::uint8_t iterations = 0;
    std::string patternHex;
};

/**
 * @brief Persistent SQLite storage for manufacturing test results.
 */
class Database {
public:
    explicit Database(const std::string& path);
    ~Database();

    Database(const Database&) = delete;
    Database& operator=(const Database&) = delete;

    void save(
        std::uint32_t testId,
        const std::string& dateTimeSent,
        double durationSeconds,
        std::uint8_t result,
        std::uint8_t peripheral,
        std::uint8_t iterations,
        const std::string& patternHex);

    std::vector<TestRecord> history() const;
    std::vector<TestRecord> get(std::uint32_t testId) const;

private:
    struct sqlite3* db_ = nullptr;

    void execute(const std::string& sql) const;
};
