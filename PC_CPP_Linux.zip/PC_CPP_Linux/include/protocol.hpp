#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace protocol {

constexpr std::uint8_t PERIPHERAL_TIMER = 0x01;
constexpr std::uint8_t PERIPHERAL_UART  = 0x02;
constexpr std::uint8_t PERIPHERAL_SPI   = 0x04;
constexpr std::uint8_t PERIPHERAL_I2C   = 0x08;
constexpr std::uint8_t PERIPHERAL_ADC   = 0x10;

constexpr std::uint8_t RESULT_SUCCESS = 0x01;
constexpr std::uint8_t RESULT_FAILURE = 0xFF;

constexpr std::size_t MAX_PATTERN_LENGTH = 255;
constexpr std::size_t MAX_COMMAND_SIZE = 7 + MAX_PATTERN_LENGTH;
constexpr std::size_t RESULT_SIZE = 5;

std::uint8_t peripheralFromName(const std::string& name);
std::string peripheralName(std::uint8_t peripheral);

std::vector<std::uint8_t> parsePattern(const std::string& text);

std::vector<std::uint8_t> buildCommand(
    std::uint32_t testId,
    std::uint8_t peripheral,
    std::uint8_t iterations,
    const std::vector<std::uint8_t>& pattern);

void parseResult(
    const std::vector<std::uint8_t>& packet,
    std::uint32_t expectedTestId,
    std::uint32_t& returnedTestId,
    std::uint8_t& result);

} // namespace protocol
